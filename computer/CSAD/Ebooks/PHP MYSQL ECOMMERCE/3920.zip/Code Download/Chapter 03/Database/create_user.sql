-- Create tshirtshopadmin user
GRANT ALL PRIVILEGES ON `tshirtshop`.*
      TO 'tshirtshopadmin'@'localhost' IDENTIFIED BY 'tshirtshopadmin'
      WITH GRANT OPTION;
