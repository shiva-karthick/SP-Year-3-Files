-- Create tshirtshop database
CREATE DATABASE `tshirtshop`
       DEFAULT CHARACTER SET 'utf8' COLLATE 'utf8_unicode_ci';
