<?php
interface IPipelineSection
{
  public function Process($processor);
}
?>
